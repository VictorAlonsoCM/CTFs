## How to install as IDA Pro plugin

Copy the folder `idangr` and the file `idangr_plugin.py` in the IDA 7 plugins subfolder.

The files `idangr_core.py` and `idangr_gui.py` must not be copied, they must be loaded as scripts if you don't want to install the plugin.
