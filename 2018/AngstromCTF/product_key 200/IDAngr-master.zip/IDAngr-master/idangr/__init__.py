from core import StateShot, StateManager
from context import load_project, set_self_modifying, is_self_modifying

