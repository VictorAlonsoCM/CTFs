#!/bin/sh

/usr/lib/x86_64-linux-gnu/qt5/bin/designer $@
