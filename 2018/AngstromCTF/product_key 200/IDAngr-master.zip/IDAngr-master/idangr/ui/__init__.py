from panel import *
from addmem import *
from execute import *
from viewer import *
from constraints import *

from syntax import PythonHighlighter
